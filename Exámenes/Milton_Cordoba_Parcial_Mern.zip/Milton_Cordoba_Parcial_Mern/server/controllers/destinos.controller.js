import { Destino } from "../models/destinos.model.js";

const destinosController = {
    getAll: async (req, res) => {
        try {
            const destinos = await Destino.find();
            return res.status(200).json(destinos);
        } catch (e) {
            return res.status(400).json(e);
        }
    },
    createOne: async (req, res) => {
        const { title, description, tips, season, cost } = req.body;
        const newData = { title, description, tips, season, cost };
        try {
            const newDestino = await Destino.create(newData);
            return res.status(201).json(newDestino);
        } catch (e) {
            const messages = {};
            if (e.name === "ValidationError") {
                Object.keys(e.errors).forEach(key => {
                    messages[key] = e.errors[key].message;
                });
            }
            if (e.code === 11000) {
                messages["duplicated"] = "El lugar ya existe";
            }
            return res.status(400).json({ errors: { ...messages } });
        }
    },
    getOne: async (req, res) => {
        const id = req.params.id;
        try {
            const one = await Destino.findById(id);
            if (!one) return res.status(404).json({ message: "El id no existe" });
            return res.status(200).json(one);
        } catch (e) {
            return res.status(400).json(e);
        }
    },
    deleteOne: async (req, res) => {
        const id = req.params.id;
        try {
            const deleted = await Destino.findByIdAndDelete(id);
            if (!deleted) return res.status(404).json({ message: "El id no existe" });
            return res.status(200).json({ message: "El destino fue eliminado exitosamente" });
        } catch (e) {
            return res.status(400).json(e);
        }
    }
    ,
    updateOne: async (req, res) => {
        const id = req.params.id;
        const { title, description, tips, season, cost } = req.body;
        const dataToUpdate = { title, description, tips, season, cost };
        try {
            const updated = await Destino.findByIdAndUpdate(id, dataToUpdate, { new: true, runValidators: true });
            if (!updated) return res.status(404).json({ message: "El id no existe" });
            return res.status(200).json(updated);
        } catch (e) {
            const messages = {};
            if (e.name === "ValidationError") {
                Object.keys(e.errors).forEach(key => {
                    messages[key] = e.errors[key].message;
                });
            }
            if (e.code === 11000) {
                messages["duplicated"] = "El lugar ya existe";
            }
            return res.status(400).json({ errors: { ...messages } });
        }
    }
};

export default destinosController;
