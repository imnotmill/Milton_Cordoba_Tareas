import { Router } from "express";
import destinosController from "../controllers/destinos.controller.js";
import validateToken from "../middleware/validateToken.js";

const destinosRoutes = Router();

destinosRoutes.get("/", validateToken, destinosController.getAll);
destinosRoutes.post("/", validateToken, destinosController.createOne);
destinosRoutes.delete("/:id", validateToken, destinosController.deleteOne);
destinosRoutes.get("/:id", validateToken, destinosController.getOne);
destinosRoutes.put("/:id", validateToken, destinosController.updateOne);

export default destinosRoutes;
