import mongoose from "mongoose";

const destinoSchema = mongoose.Schema(
  {
    title: {
      type: String,
      minlength: [3, "El lugar debe tener al menos 3 caracteres"],
      required: [true, "El título es obligatorio"],
      unique: true
    },
    description: {
      type: String,
      minlength: [10, "La descripción debe tener al menos 10 caracteres"],
      required: [true, "La descripción es obligatoria"]
    },
    tips: {
      type: String,
      minlength: [10, "Los tips deben tener al menos 10 caracteres"],
      required: [true, "Los tips son obligatorios"]
    },
    season: {
      type: String,
      required: [true, "La época es obligatoria"]
    },
    cost: {
      type: Number,
      min: [0, "El costo debe ser un número positivo"],
      required: [true, "El costo es obligatorio"]
    }
  },
  { timestamps: true }
);

const Destino = mongoose.model("destinos", destinoSchema);
export { Destino, destinoSchema };
