const NotFound = () => {

    return(
        <div style={{height: '100%'}}>
            <h2>La cancion no existe</h2>
            <img src="https://i.gifer.com/2RNE.gif" alt="Not found" />
        </div>
    )
}

export default NotFound;